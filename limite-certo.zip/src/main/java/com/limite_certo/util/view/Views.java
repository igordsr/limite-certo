package com.limite_certo.util.view;


public class Views {
    public static class Completo {}
    public static class Parcial {}
    public static class IdView {}
    public static class None {}
}
